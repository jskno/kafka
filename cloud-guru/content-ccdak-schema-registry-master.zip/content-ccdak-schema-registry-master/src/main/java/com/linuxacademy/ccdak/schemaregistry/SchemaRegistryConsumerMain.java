package com.linuxacademy.ccdak.schemaregistry;

public class SchemaRegistryConsumerMain {

    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }

}
