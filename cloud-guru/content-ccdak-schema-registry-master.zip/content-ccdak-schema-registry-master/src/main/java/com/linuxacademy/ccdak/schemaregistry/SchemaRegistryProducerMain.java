package com.linuxacademy.ccdak.schemaregistry;

public class SchemaRegistryProducerMain {

    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }

}
