package com.linuxacademy.ccdak.consumer;

public class Main {

    public static void main(String[] args) {
        MemberSignupsConsumer memberSignupsConsumer = new MemberSignupsConsumer();
        memberSignupsConsumer.run();
    }

}
