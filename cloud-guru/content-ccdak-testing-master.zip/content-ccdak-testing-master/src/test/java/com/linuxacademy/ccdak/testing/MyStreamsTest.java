package com.linuxacademy.ccdak.testing;

/**
 *
 * @author will
 */
public class MyStreamsTest {
    
}
