package com.linuxacademy.ccdak.testing;

/**
 *
 * @author will
 */
public class MyProducerTest {
    
}
