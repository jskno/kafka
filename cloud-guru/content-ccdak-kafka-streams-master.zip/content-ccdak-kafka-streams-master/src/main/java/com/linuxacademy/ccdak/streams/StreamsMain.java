package com.linuxacademy.ccdak.streams;

public class StreamsMain {

    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }

}
